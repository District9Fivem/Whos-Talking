-- fxmanifest.lua
fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Adds a circle around players when they are talking'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'
