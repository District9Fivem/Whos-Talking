-- client.lua

local talkingPlayers = {}

-- Update the list of talking players
RegisterNetEvent('updateTalkingPlayers')
AddEventHandler('updateTalkingPlayers', function(players)
    talkingPlayers = players
end)

-- Monitor talking state and notify the server
Citizen.CreateThread(function()
    while true do
        local isTalking = NetworkIsPlayerTalking(PlayerId())
        TriggerServerEvent('playerTalkingStateChanged', isTalking)
        Citizen.Wait(500)
    end
end)

-- Main thread to draw a flat, smaller circle around talking players
Citizen.CreateThread(function()
    local bobbingHeight = 0.01   -- Minimal bobbing, keeping it close to the ground
    local bobbingSpeed = 5.0     -- Speed of the bobbing effect (still subtle)

    while true do
        for playerId, isTalking in pairs(talkingPlayers) do
            if isTalking then
                local ped = GetPlayerPed(GetPlayerFromServerId(playerId))
                if DoesEntityExist(ped) then
                    local coords = GetEntityCoords(ped)
                    
                    -- Calculate slight vertical offset for subtle bobbing
                    local time = GetGameTimer() / 1000
                    local zOffset = math.sin(time * bobbingSpeed) * bobbingHeight

                    -- Draw a flat, smaller circle around the player's feet
                    DrawMarker(
                        27,                               -- Marker type 27 is a flat circle
                        coords.x, coords.y, coords.z - 0.98 + zOffset, -- Position (close to ground level)
                        0.0, 0.0, 0.0,                    -- Direction
                        0.0, 0.0, 0.0,                    -- Rotation
                        0.9, 0.9, 0.01,                   -- Scale (smaller and flat)
                        255, 255, 255, 150,               -- Color (white, semi-transparent)
                        false, true, 2,                   -- Unknown parameters for drawing behavior
                        nil, nil, false                   -- Extra parameters for rotation and texture
                    )
                end
            end
        end

        Citizen.Wait(0)
    end
end)
