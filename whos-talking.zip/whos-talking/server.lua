-- server.lua

local talkingPlayers = {}

RegisterNetEvent('playerTalkingStateChanged')
AddEventHandler('playerTalkingStateChanged', function(isTalking)
    local src = source
    talkingPlayers[src] = isTalking

    -- Broadcast to all clients the list of currently talking players
    TriggerClientEvent('updateTalkingPlayers', -1, talkingPlayers)
end)

-- Remove players from talking list when they disconnect
AddEventHandler('playerDropped', function()
    local src = source
    talkingPlayers[src] = nil
    TriggerClientEvent('updateTalkingPlayers', -1, talkingPlayers)
end)
